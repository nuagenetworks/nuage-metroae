BRANDING_INFORMATION = {
    "label-application-name" : "Nuage Networks powered by MetroAE",
    "label-company-name" : "Nuage Networks powered by MetroAE",
    "use-powered-by" : false,
    "logo-application-file" : "logo-application.png",
    "logo-company-file" : "logo-company.png",
    "background-file" : "background.jpg"
};
