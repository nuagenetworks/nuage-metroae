BRANDING_INFORMATION = {
    "label-application-name" : "Nuage Networks powered by MetroAE",
    "label-company-name" : "Nuage Networks powered by MetroAE",
    "use-powered-by" : false,
};
