BRANDING_INFORMATION = {

    "label-application-name"    : "Virtualized Services Architect",
    "label-company-name"        : "Nuage Networks deployed by MetroAE",
    "use-powered-by"            : false,
    "logo-application-file" : "logo-application.png",
    "logo-company-file" : "logo-company.png",
    "background-file" : "background.jpg"
};
