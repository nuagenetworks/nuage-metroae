BRANDING_INFORMATION = {

    "label-application-name"    : "Virtualized Services Architect",
    "label-company-name"        : "Nuage Networks deployed by MetroAE",
    "use-powered-by"            : false

};
