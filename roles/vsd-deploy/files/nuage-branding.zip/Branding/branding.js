BRANDING_INFORMATION = {

    "label-application-name"    : "Virtualized Services Architect deployed by MetroAE",
    "label-company-name"        : "Nuage Networks deployed by MetroAE",
    "use-powered-by"            : false

};
